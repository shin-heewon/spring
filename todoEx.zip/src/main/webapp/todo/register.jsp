<%--
  Created by IntelliJ IDEA.
  User: a
  Date: 2024-09-05
  Time: 오후 5:20
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>register</title>
</head>
<body>
<form action="/todo/register" method="post">
<input type="text" placeholder="INSERT TITLE">
    <input TYPE="date" >
    <BUTTON type="reset">RESET</BUTTON>
    <BUTTON type="submit">SUBMIT</BUTTON>

</form>

</body>
</html>
