<%--
  Created by IntelliJ IDEA.
  User: a
  Date: 2024-09-05
  Time: 오후 5:48
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<form>
<input type="text" name="tno" value="${vo.tno}"><br>
<input type="text" name="title" value="${vo.title}"><br>
<input type="date" name="dueDate" value="${vo.dueDate}"><br>
<input type="checkbox" name="finished" ${vo.finished ? "checked": ""} readonly ><br>

<div>
    <a href="/todo/modify?tno=${vo.tno}">Modify/Remove</a>
    <a href="/todo/list">List</a>
</div>
</form>
</body>
</html>
