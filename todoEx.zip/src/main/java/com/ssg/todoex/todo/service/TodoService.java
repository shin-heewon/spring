package com.ssg.todoex.todo.service;


import com.ssg.todoex.todo.dao.TodoDAO;
import com.ssg.todoex.todo.domain.TodoVO;
import com.ssg.todoex.todo.dto.TodoDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public enum TodoService {

    INSTANCE; // 이 통로를 이용해야지만 서비스를 이용할 수 있도록 함
    TodoDAO dao = new TodoDAO();

    public void register(TodoDTO dto){//하나의 글을 등록하는 기능
        System.out.println("DEBUG................"+dto);
    }

    public List<TodoVO> getList() throws Exception{//등록된 글 목록 반환하는 기능

        return dao.selectAllList();
    }

    public TodoVO selectOne(Long tno) throws Exception {

        return dao.selectOne(tno);
    }

    public TodoVO updateOne(TodoVO vo) throws Exception{
        dao.updateOne(vo);
        return selectOne(vo.getTno());
    }





}
