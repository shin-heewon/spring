package com.ssg.todoex.todo.service;

import com.ssg.todoex.todo.domain.TodoVO;
import com.ssg.todoex.todo.dto.TodoDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "todoReadController", urlPatterns = "/todo/read")
public class TodoReadController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("todo/read......실행");

        Long tno = Long.parseLong(req.getParameter("tno"));

        TodoVO vo = null;
        try {
           vo = TodoService.INSTANCE.selectOne(tno);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        req.setAttribute("vo", vo);
        req.getRequestDispatcher("/todo/read.jsp").forward(req, resp);
    }

}
