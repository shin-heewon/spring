package com.ssg.todoex.todo.service;

import com.ssg.todoex.todo.domain.TodoVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "todoModifyController" , urlPatterns = "/todo/modify")
public class TodoModifyController extends HttpServlet  {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long tno = Long.parseLong(req.getParameter("tno"));

        TodoVO vo = req.getParameter();
        try {
            vo = TodoService.INSTANCE.updateOne();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        req.setAttribute("vo", vo);
        req.getRequestDispatcher("/todo/read.jsp").forward(req, resp);
    }
    }
}
